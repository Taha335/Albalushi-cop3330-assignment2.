/*
 * UCF COP3330 Fall 2021 Assignment 2 Solution
 * Copyright 2021 Taha Al Balushi
 */

package ex25;
import java.util.Scanner;

public class Password {
    public static void main(String ar[]) {
        Scanner sc = new Scanner(System.in);
        String password="1337h@xor!";
        int res=passwordValidator(password);
        String output="";
        if(res==0)
            output="The password '"+password+"' is a very week password.";
        else if(res==1)
            output="The password '"+password+"' is a week password.";
        else if (res==2)
            output="The password '"+password+"' is a strong password.";
        else if(res==3)
            output="The password '"+password+"' is a very strong password.";
        System.out.print(output);
    }
    public static int passwordValidator(String str)
    {
        int res=0;
        int num=0;
        int ch=0;
        int specialChar=0;
        int length=str.length();

            for(int i=0;i<length;i++)
            {
               if( Character.isLetter(str.charAt(i)))
                        ch++;
                else if(Character.isDigit(str.charAt(i)))
                    num++;
                else if(Character.isWhitespace(str.charAt(i)))
                    specialChar++;
            }
            if(length<8 && num==length)
                res=0;
            else if(ch==length && length<8)
                res=1;
            else if(ch>0 && num>0 && specialChar==0 && length>=8)
                res=2;
            else if(ch>0 && num>0 && specialChar>0 && length>=8)
                res=3;
return res;
    }
}
